﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BananaSplit
{
    /// <summary>
    /// Interaction logic for TimeFixer.xaml
    /// </summary>
    public partial class TimeFixer : Window
    {
        TimeSpan[] TempTimeStore = new TimeSpan[16];
        int IndexNum = 0;

        public TimeFixer()
        {
            InitializeComponent();
            if (MainWindow.isPBMissingSplits)
            {
                FindEmptySplit();
            }
            else
            {
                Label_Instruction.Content = "Your splits seem to not miss any...";
                Label_TrackName.Content = "-";
                Button_Next.Visibility = System.Windows.Visibility.Hidden;
                Button_Cancel.Content = "Close";
            }
        }

        void FindEmptySplit()
        {
            while (IndexNum < 16)
            {
                if (MainWindow.PBSplits[IndexNum] == TimeSpan.Zero)
                {
                    switch (IndexNum)
                    {
                        case 0:
                            Label_TrackName.Content = "Luigi Circuit";
                            break;
                        case 1:
                            Label_TrackName.Content = "Peach Beach";
                            break;
                        case 2:
                            Label_TrackName.Content = "Baby Park";
                            break;
                        case 3:
                            Label_TrackName.Content = "Dry Dry Desert";
                            break;
                        case 4:
                            Label_TrackName.Content = "Mushroom Bridge";
                            break;
                        case 5:
                            Label_TrackName.Content = "Mario Circuit";
                            break;
                        case 6:
                            Label_TrackName.Content = "Daisy Cruiser";
                            break;
                        case 7:
                            Label_TrackName.Content = "Waluigi Stadium";
                            break;
                        case 8:
                            Label_TrackName.Content = "Sherbet Land";
                            break;
                        case 9:
                            Label_TrackName.Content = "Mushroom City";
                            break;
                        case 10:
                            Label_TrackName.Content = "Yoshi Circuit";
                            break;
                        case 11:
                            Label_TrackName.Content = "DK Mountain";
                            break;
                        case 12:
                            Label_TrackName.Content = "Wario Colosseum";
                            break;
                        case 13:
                            Label_TrackName.Content = "Dino Dino Jungle";
                            break;
                        case 14:
                            Label_TrackName.Content = "Bowser's Castle";
                            break;
                        case 15:
                            Label_TrackName.Content = "Rainbow Road";
                            break;
                    }
                    break;
                }
                IndexNum++;
            }
        }

        void NextButtonClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                TempTimeStore[IndexNum] = TimeSpan.FromMinutes(Convert.ToDouble(CB_Minutes.SelectedItem)) + TimeSpan.FromSeconds(Convert.ToDouble(CB_Seconds.SelectedItem));
                FindEmptySplit();
                if (IndexNum > 15)
                {
                    for (int i = 0; i < 16; i++)
                    {
                        if (TempTimeStore[IndexNum] > TimeSpan.Zero) MainWindow.PBSplits[IndexNum] = TempTimeStore[IndexNum];
                    }
                    System.Windows.MessageBox.Show("All your missing splits should now be filled in.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                    Close();
                }
            }
            catch(InvalidCastException)
            {
                System.Windows.MessageBox.Show("Please do not leave any times empty.");
            }

        }

        void CancelButtonClick(object sender, MouseButtonEventArgs e)
        {
            Close();
        }
    }
}
