Program by Yannik Braendle aka MisterIXI.

The savefile is created once you save your splits (or settings), this will be prompted after resetting and closing. 

Any questions can be sent to me on discord (MisterIXI#1504) or in the speedrun.com/mkdd forum thread.

I will answer all questions regarding the programming itself and also give out the source code if anyone is interested. (The Program a WPF application written in C# in Visual Studio)

Default Controls:
Start / Split: NumPad1
Reset: NumPad3
Skip Split: NumPad2
Undo Selection: NumPad8
Save everything: Ctrl + S

--For global hotkey functionality the GlobalHotkey option must be set on startup.

Changelog: (DD/MM/YYYY)


8/11/2016 		1.0

-Release



9/11/2016		1.1

-Added ChromaKey mode
-fixed some visual bugs
-fixed displaying +/-1 minute times


